$(document).ready(function(){
//������Ϣ
//��Ṥ��
	$("#jiben_shehui").hide();
  $("#add_jiben_shehui").click(function(){
    $("#jiben_shehui").show();
  });

//��������
	$("#jiben_dangke").hide();
  $("#add_jiben_dangke").click(function(){
    $("#jiben_dangke").show();
  })
//����С��
//С��
	$("#dangke_xiaozu").hide();
  $("#add_dangke_xiaozu").click(function(){
    $("#dangke_xiaozu").show();
  });

//˼��ƽ̨
	$("#dangke_sibian").hide();
  $("#add_dangke_sibian").click(function(){
    $("#dangke_sibian").show();
  });

//������
	$("#dangke_qiusuo").hide();
  $("#add_dangke_qiusuo").click(function(){
    $("#dangke_qiusuo").show();
  });

//����ѧϰ
//����ѧϰ
	$("#zizhu_lilun").hide();
  $("#add_zizhu_lilun").click(function(){
    $("#zizhu_lilun").show();
  });
//�����
	$("#zizhu_huodong").hide();
  $("#add_zizhu_huodong").click(function(){
    $("#zizhu_huodong").show();
  });
//����Ͷ��
	$("#zizhu_tougao").hide();
  $("#add_zizhu_tougao").click(function(){
    $("#zizhu_tougao").show();
  });

//֧��
//��ϵ���
	$("#zhibu_lianxi").hide();
  $("#add_zhibu_lianxi").click(function(){
    $("#zhibu_lianxi").show();
  });
//˼��㱨
	$("#zhibu_huibao").hide();
  $("#add_zhibu_huibao").click(function(){
    $("#zhibu_huibao").show();
  });
//֧���
	$("#zhibu_zhibu").hide();
  $("#add_zhibu_zhibu").click(function(){
    $("#zhibu_zhibu").show();
  });

//֧���
	$("#yubei_huibao").hide();
  $("#add_yubei_huibao").click(function(){
    $("#yubei_huibao").show();
  });

});





