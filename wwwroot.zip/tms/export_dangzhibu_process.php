<?php
$dangzhibu=$_GET['dangzhibu'];
include ('config/db.php');
include ('function/export.php');
$sql="select id from useraccount where dangzhibu='".$dangzhibu."'";
$DB->query($sql);
$ans=$DB->get_rows_array();
if ($ans)
	{	
		$filename="tmpfile/".$dangzhibu."output.csv";	
		$fp = fopen($filename, 'w');
		fputcsv($fp,GenerateTitie1());
		fputcsv($fp,GenerateTitie2());
		fputcsv($fp,GenerateTitie3());
		$num=$DB->get_rows();
		for ($i=0;$i<$num;$i++)
		{
			$sample=$ans[$i];
			$id=$sample[0];
			//echo $id;
			$final=export_one($id);
			$line=count($final);
			for ($j=0;$j<$line;$j++) 
			{
				fputcsv($fp,$final[$j]);
			}
		}
		fclose($fp); 
	}else
			{
				echo "�����ݣ�";
				echo "<button onclick=\"window.location='home.php'\">������ҳ</button>";
			}

$file_dir="tmpfile/";
$name=$dangzhibu."output.csv";
$file = fopen($file_dir.$name,"r"); 
header("Content-Type: text/csv");  
Header("Content-type: application/octet-stream");
Header("Accept-Ranges: bytes");
header('Content-Transfer-Encodeing: binary');
Header("Accept-Length: ".filesize($file_dir . $name));
Header("Content-Disposition: attachment; filename=".$name);
echo fread($file, filesize($file_dir.$name));
die();
fclose($file);
?>

