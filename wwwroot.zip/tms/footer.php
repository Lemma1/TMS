<footer class="bs-footer">
	<div class="container">
	copyright 2014
	</div>
</footer>
